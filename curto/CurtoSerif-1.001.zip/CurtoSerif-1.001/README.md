# Curto Serif

Version 1.001 — webfont build.

Curto Serif is a contemporary display serif for editorial layouts, identities and titles.
Regular 400 is production-ready. Medium, SemiBold, Bold and the variable builds are in beta testing.

## Files

- `fonts/webfonts/` — static and variable WOFF2 files
- `curto.css` — ready-to-use @font-face declarations
- `OFL.txt` — SIL Open Font License 1.1

## Basic use

```css
body {
  font-family: "Curto Serif", Georgia, serif;
  font-weight: 400;
}
```

The variable family covers `wght` 400–700:

```css
h1 {
  font-family: "Curto Serif Variable", Georgia, serif;
  font-weight: 650;
}
```

## License

Licensed under the SIL Open Font License, Version 1.1. See `OFL.txt`.
